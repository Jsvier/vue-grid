# Changelog

### 1.1.8 (August 11, 2017)

* Bug fix - Issue 5 - Axios config not being loaded with GET method and Delegate false.

### 1.1.7 (August 10, 2017)

* Allowing Axios configuration to be passed for the requests

### 1.1.6 (June 29, 2017)

* Search case sensitivity configurable

### 1.1.5 (June 21, 2017)

* Row Click Handler added

### 1.1.4 (June 12, 2017)

* Fix- delegate now doesn't use echo

## 1.1.3  (June 5, 2017)

* Define a Render Function support by column
* Define Column Styles by column
* Define Cell Styles by column

## 1.1.2 (June 2, 2017)

* Fix to Sorting
* Added Multicolumn Sorting
* Fix dynamic adding rows with update to interface
* Ajax with multicolumn sorting

## 1.1.1 (June 1, 2017)

* Added more Events

## 1.1.0 (May 30, 2017)

* Remote data loading (through ajax call)
* Remote data processing (through ajax calls)
* Loading overlay

## 1.0.2 (May 26, 2017)

* Added Pagination support
* Added Edit on Table support

## 1.0.1 (Sep 16, 2016)

* bugfix: clear displayCols when columns change

## 1.0.0 (Aug 23, 2016)

* First Version
