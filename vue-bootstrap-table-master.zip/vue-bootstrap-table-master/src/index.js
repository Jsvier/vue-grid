import VueBootstrapTable from './VueBootstrapTable.vue';

module.exports = VueBootstrapTable;
